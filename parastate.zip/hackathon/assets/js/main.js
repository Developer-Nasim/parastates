(function($) {
    "use strict";





})(jQuery);